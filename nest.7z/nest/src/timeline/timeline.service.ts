import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { TimelineModel } from './timeline.model';

@Injectable()
export class TimelineService {
    constructor(
        @InjectRepository(TimelineModel)
        private timelineRepository: Repository<TimelineModel>,
      ) {}

      create(details: TimelineModel): Promise<TimelineModel>{
          return this.timelineRepository.save(details);
      }
    
      findAll(): Promise<TimelineModel[]> {
        return this.timelineRepository.find();
      }

      findByPatient(patientId: string): Promise<TimelineModel[]> {
          return this.timelineRepository.find({patientId})
      }
    
}