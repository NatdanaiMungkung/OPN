import { Resolver, Mutation, Args, Query, ResolveField, Parent } from '@nestjs/graphql';
import { Inject } from '@nestjs/common';
import { Gender, PatientModel } from './patient.model';
import { TimelineModel } from '../timeline/timeline.model';
import { TimelineService } from 'src/timeline/timeline.service';
import { PatientService } from './patient.service';
@Resolver(of => PatientModel)
export class PatientResolver {
  constructor(
    @Inject(TimelineService) private timelineService: TimelineService,
    @Inject(PatientService) private patientService: PatientService
  ) { }
  @Query(returns => PatientModel)
  async patient(@Args('id') id: string): Promise<PatientModel> {
    return await this.patientService.findOne(id);
  }
  @ResolveField(returns => [TimelineModel])
  async timelines(@Parent() patient) {
    const { id } = patient;
    console.log(patient);
    return this.timelineService.findByPatient(id);
  }
  @Query(returns => [PatientModel])
  async patients(): Promise<PatientModel[]> {
    return await this.patientService.findAll();
  }
  @Mutation(returns => PatientModel)
  async createPatient(
    @Args('gender') gender: Gender,
    @Args('age') age: number,
    @Args('occupation') occupation: string,
  ): Promise<PatientModel> {
    return await this.patientService.create({gender, age, occupation});
  }

  @Mutation(returns => Boolean)
  async removePatient(
    @Args('id') id: string): Promise<Boolean> {
    return await this.patientService.remove(id);
  }
}